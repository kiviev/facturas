DROP DATABASE IF EXISTS gestion;
CREATE DATABASE gestion;
USE gestion;

CREATE TABLE clientes (
    id          INT PRIMARY KEY AUTO_INCREMENT,
    cif         VARCHAR(10),
    nombre      VARCHAR(100),
    direccion   VARCHAR(150),
    poblacion   VARCHAR(100),
    provincia   VARCHAR(100),
    cod_postal  VARCHAR(10)
);

CREATE TABLE facturas   (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    fecha_emision   DATE,
    cliente_id      INT
);


CREATE TABLE albaranes  (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    cliente_id      INT,
    fecha_emision   DATE,
    fecha_entrega   DATE,
    factura_id      INT
);


CREATE TABLE productos  (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    nombre          VARCHAR(100),
    tipo            VARCHAR(100),
    precio_compra   DECIMAL(10,2),
    precio_venta    DECIMAL(10,2)
);

CREATE TABLE albaranes_productos  (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    albaran_id      INT,
    producto_id     INT,
    cantidad        DECIMAL(6,2)
);


INSERT INTO clientes (  id,
                        cif,
                        nombre,
                        direccion,
                        poblacion,
                        provincia,
                        cod_postal)
        VALUES      ( 1, 'A-1111111', 'Cliente 1', 'Dirección de cliente 1', 'Alcorcón', 'Madrid', '28921'),
                    ( 2, 'A-2222222', 'Cliente 2', 'Dirección de cliente 2', 'Alcorcón', 'Madrid', '28921'),
                    ( 3, 'A-3333333', 'Cliente 3', 'Dirección de cliente 3', 'Móstoles', 'Madrid', '28929'),
                    ( 4, 'A-4444444', 'Cliente 4', 'Dirección de cliente 4', 'Badalona', 'Barcelona', '05142'),
                    ( 5, 'A-5555555', 'Cliente 5', 'Dirección de cliente 5', 'Toledo', 'Toledo', '83746')
;

