DROP DATABASE IF EXISTS gestion;
CREATE DATABASE gestion;
USE gestion;

CREATE TABLE clientes (
    id          INT PRIMARY KEY AUTO_INCREMENT,
    cif         VARCHAR(10),
    nombre      VARCHAR(100),
    direccion   VARCHAR(150),
    poblacion   VARCHAR(100),
    provincia   VARCHAR(100),
    cod_postal  VARCHAR(10)
);

CREATE TABLE facturas   (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    fecha_emision   DATE,
    cliente_id      INT
);


CREATE TABLE albaranes  (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    cliente_id      INT,
    fecha_emision   DATE,
    fecha_entrega   DATE,
    factura_id      INT
);


CREATE TABLE productos  (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    nombre          VARCHAR(100),
    tipo            VARCHAR(100),
    precio_compra   DECIMAL(10,2),
    precio_venta    DECIMAL(10,2)
);

CREATE TABLE albaranes_productos  (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    albaran_id      INT,
    producto_id     INT,
    cantidad        DECIMAL(6,2)
);


