DROP DATABASE IF EXISTS gestion;
CREATE DATABASE gestion;
USE gestion;

CREATE TABLE clientes (
    id          INT PRIMARY KEY AUTO_INCREMENT,
    cif         VARCHAR(10),
    nombre      VARCHAR(100),
    direccion   VARCHAR(150),
    poblacion   VARCHAR(100),
    provincia   VARCHAR(100),
    cod_postal  VARCHAR(10)
);

CREATE TABLE facturas   (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    fecha_emision   DATE,
    cliente_id      INT
);


CREATE TABLE albaranes  (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    cliente_id      INT,
    fecha_emision   DATE,
    fecha_entrega   DATE,
    factura_id      INT
);


CREATE TABLE productos  (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    nombre          VARCHAR(100),
    tipo            VARCHAR(100),
    precio_compra   DECIMAL(10,2),
    precio_venta    DECIMAL(10,2)
);

CREATE TABLE albaranes_productos  (
    id              INT PRIMARY KEY AUTO_INCREMENT,
    albaran_id      INT,
    producto_id     INT,
    cantidad        DECIMAL(6,2)
);


INSERT INTO clientes (  id,
                        cif,
                        nombre,
                        direccion,
                        poblacion,
                        provincia,
                        cod_postal)
        VALUES      ( 1, 'A-1111111', 'Cliente 1', 'Dirección de cliente 1', 'Alcorcón', 'Madrid', '28921'),
                    ( 2, 'A-2222222', 'Cliente 2', 'Dirección de cliente 2', 'Alcorcón', 'Madrid', '28921'),
                    ( 3, 'A-3333333', 'Cliente 3', 'Dirección de cliente 3', 'Móstoles', 'Madrid', '28929'),
                    ( 4, 'A-4444444', 'Cliente 4', 'Dirección de cliente 4', 'Badalona', 'Barcelona', '05142'),
                    ( 5, 'A-5555555', 'Cliente 5', 'Dirección de cliente 5', 'Toledo', 'Toledo', '83746')
;

INSERT INTO productos ( id,
                        nombre,
                        tipo,
                        precio_compra,
                        precio_venta )
VALUES
(1, "Samsung Galaxy J5", "Telefonía móvil", 145.25, 199.00),
(2, "Huawei P8 Lite Negro", "Telefonía móvil", 155.15, 206.00),
(3, "Sony Experia C4", "Telefonía móvil", 247.80, 315.50),
(4, "TV Sony Bravia KD55X8507C", "TV", 1150.25, 1349.50),
(5, "TV Led 43 Samsung 43J5570", "TV", 325.80, 499.99),
(6, "TV Led 49 LG 49LF590V", "TV", 425.75, 594.00),
(7, "Canon EOS 1200D + 18-55 f3", "Fotografía", 315.00, 321.00),
(8, "Nikon D610 body", "Fotografía", 1210.50, 1395.50),
(9, "Bowers and Wilkins A5", "Audio", 415.25, 499.99),
(10, "Harman Kardon Onyxs Studio", "Audio", 128.50, 141.50)
;

INSERT INTO facturas (id, fecha_emision, cliente_id)
VALUES
(1, "2014-01-15", 1),
(2, "2014-02-7", 2),
(3, "2014-02-9", 4),
(4, "2014-03-19", 5),
(5, "2014-03-21", 3),
(6, "2014-04-22", 2),
(7, "2014-04-4", 3),
(8, "2014-05-1", 4),
(9, "2014-06-5", 2),
(10, "2014-07-10", 1),
(11, "2014-08-23", 3),
(12, "2014-09-27", 4),
(13, "2014-10-20", 3),
(14, "2014-10-4", 1),
(15, "2014-11-1", 3),
(16, "2014-12-4", 2),
(17, "2015-01-25", 2),
(18, "2015-01-14", 1),
(19, "2015-01-15", 4),
(20, "2015-02-19", 2),
(21, "2015-02-22", 5),
(22, "2015-03-23", 1),
(23, "2015-03-12", 3),
(24, "2015-03-22", 5),
(25, "2015-04-1", 5),
(26, "2015-04-4", 3),
(27, "2015-04-25", 2),
(28, "2015-05-7", 3),
(29, "2015-05-12", 3),
(30, "2015-06-2", 5),
(31, "2015-06-12", 3),
(32, "2015-06-19", 2),
(33, "2015-06-21", 1);

INSERT INTO albaranes (id, factura_id,fecha_emision, fecha_entrega, cliente_id)
VALUES
(1, 1, "2014-01-15","2014-01-15",1),
(1, 2, "2014-02-7","2014-02-7",2),
(1, 3, "2014-02-9", "2014-02-9", 4),
(1, 4, "2014-03-19", "2014-03-19", 5),
(1, 5, "2014-03-21", "2014-03-21", 3),
(1, 6, "2014-04-22", "2014-04-22", 2),
(1, 7, "2014-04-4", "2014-04-4", 3),