<?php

	// Funciones de gestión de base de datos
	
    require_once("cnf/connection_info.php");
    
    function f_conn($p_def_schema = DB_CONN_DEF_SCHEMA) {
        
        
        $bd = new mysqli(DB_CONN_HOST, DB_CONN_USER, DB_CONN_PASS, $p_def_schema);
    
        return $bd;
        
    }


?>
