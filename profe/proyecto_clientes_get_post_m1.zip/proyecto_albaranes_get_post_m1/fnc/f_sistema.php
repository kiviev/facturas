<?php

	// Funciones generales del sistema
	function f_echo($p_texto, $p_linefeed=1) {
        
        $texto=str_replace(array("á","é","í","ó","ú","ñ","Á","É","Í","Ó","Ú","Ñ"),
                array("&aacute;","&eacute;","&iacute;","&oacute;","&uacute;","&ntilde;",
                "&Aacute;","&Eacute;","&Iacute;","&Oacute;","&Uacute;","&Ntilde;"), $p_texto);     
        
        echo $texto;
        
        if ( $p_linefeed ) {
            echo "\n";
        }
    }
        

?>
