<?php

	// Script para gestionar DETALLE DE ALBARANES
	
	f_echo("Código para gestionar Detalle de Albaranes");
        
        // Comprobar acciones
	$v_code = $_GET["code"];
                
        $v_conn = f_conn();
	
	$v_query = "SELECT id, fecha_emision, fecha_entrega, cliente_id, factura_id FROM albaranes WHERE id=$v_code";
	$v_data = $v_conn->query($v_query);
	$v_row = $v_data->fetch_assoc();
        
        $v_query1 = "SELECT id, nombre FROM clientes WHERE id=".$v_row["cliente_id"];
	$v_data1 = $v_conn->query($v_query1);
	$v_row1 = $v_data1->fetch_assoc();
        
        $v_query2 = "SELECT id, nombre FROM facturas WHERE id=".$v_row['factura_id'];
	$v_data2 = $v_conn->query($v_query2);
	$v_row2 = $v_data2->fetch_assoc();

        f_echo("<hr>");
	f_echo("<h2>Detalle de Albaranes</h2>");
        f_echo("<hr>");
        f_echo("<table border=1>");
	        
	f_echo("<tr><td>Código : "."</td><td></td><td>".$v_row["id"]."</td></tr>");
	f_echo("<tr><td>Fecha de Emisión : "."</td><td></td><td>".$v_row["fecha_emision"]."</td></tr>");
	f_echo("<tr><td>Cliente : "."</td><td>".$v_row["cliente_id"]."</td><td>".$v_row1["nombre"]."</td></tr>");
	
	f_echo("</table>");
        
# Borrar los datos leidos de la tabla
$v_data->close();
$v_data1->close();
# Desconectar MySQL server
$v_conn->close();

?>