<?php

	// Script para gestionar ALBARANES
	
	f_echo("Código para gestionar Albaranes");
        
	$v_conn = f_conn();
	
	$v_query = "SELECT id, fecha_emision, fecha_entrega, cliente_id, factura_id
				FROM albaranes";
	
	$v_data = $v_conn->query($v_query);
	
	
	f_echo("<table border=1>");
	f_echo("<tr><th>id</th><th>Fecha Emisión</th><th>Fecha Entrega</th>
		   <th>Cod. Cliente</th><th>Cod. Factura</th></tr>");
                   	
	while ($v_row = $v_data->fetch_assoc()) {
		f_echo("<tr>");
		f_echo("<td><a href='?accion=det_albaran&code=".$v_row["id"]."'>".$v_row["id"]."</a></td>");
		f_echo("<td>".$v_row["fecha_emision"]."</td>");
		f_echo("<td>".$v_row["fecha_entrega"]."</td>");
		f_echo("<td>".$v_row["cliente_id"]."</td>");
		f_echo("<td>".$v_row["factura_id"]."</td>");
                f_echo("</tr>");
	}
	f_echo("</table>");

# Borrar los datos leidos de la tabla
$v_data->close();
# Desconectar MySQL server
$v_conn->close();

?>
