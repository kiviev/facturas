<?php

	// Script para gestionar CLIENTES

	f_echo("Código para gestionar Clientes");
        
	$v_conn = f_conn();
	
	$v_query = "SELECT id, cif, nombre, direccion, poblacion, provincia, cod_postal
				FROM clientes";
	
	$v_data = $v_conn->query($v_query);
	
	f_echo("<table border=1>");
	f_echo("<tr><th>id</th><th>Nombre</th><th>C.I.F.</th>
			<th>Dirección</th><th>Población</th>
            <th>Provincia</th><th>Cód. Postal</th></tr>");
	
	while ($v_row = $v_data->fetch_assoc()) {
		f_echo("<tr>");
		f_echo("<td><a href='?accion=det_cliente&code=".$v_row["id"]."'>".$v_row["id"]."</a></td>");
		f_echo("<td>".$v_row["nombre"]."</td>");
		f_echo("<td>".$v_row["cif"]."</td>");
		f_echo("<td>".$v_row["direccion"]."</td>");
		f_echo("<td>".$v_row["poblacion"]."</td>");
        f_echo("<td>".$v_row["provincia"]."</td>");
        f_echo("<td>".$v_row["cod_postal"]."</td>");
        f_echo("
				<form action='index.php' method='POST'>
				<input type='hidden' name='accion' value='det_cliente'>
				<input type='hidden' name='cliente_id' value='".$v_row["id"]."'>
				<td>
				<input type='submit' name='boton' value='Ver'>
				</td>
				</form>
				");
		f_echo("</tr>");

	}
	f_echo("</table>");
  
        
# Borrar los datos leidos de la tabla
$v_data->close();
# Desconectar MySQL server
$v_conn->close();

?>
