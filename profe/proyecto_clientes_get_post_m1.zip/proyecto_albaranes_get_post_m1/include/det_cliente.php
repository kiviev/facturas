<?php

// Script para gestionar DETALLE DE CLIENTES
	
f_echo("Código para gestionar Detalle de Clientes");
        
	$v_frm_boton = $_POST["boton"];
	
// Comprobar acciones
if( $v_frm_boton ) {        
    
    $v_code = $_POST["cliente_id"];

} else {

    $v_code = $_GET["code"];   
  
}

//	$v_code = $_GET["code"];
        
	$v_conn = f_conn();
	
	$v_query = "SELECT id, cif, nombre, direccion, poblacion, provincia, cod_postal
				FROM clientes WHERE id = $v_code";
	
	$v_data = $v_conn->query($v_query);
	
	$v_row = $v_data->fetch_assoc();
                f_echo("<hr>");
		f_echo("<h2>Detalle del Clientes</h2>");
		f_echo("<hr>");
                f_echo("<table border=1>");
                f_echo("<tr><td>Código : "."</td><td>".$v_row["id"]."</td></tr>");
		f_echo("<tr><td>Nombre : "."</td><td>".$v_row["nombre"]."</td></tr>");
		f_echo("<tr><td>C.I.F. : "."</td><td>".$v_row["cif"]."</td></tr>");
		f_echo("<tr><td>Dirección : "."</td><td>".$v_row["direccion"]."</td></tr>");
		f_echo("<tr><td>Población : "."</td><td>".$v_row["poblacion"]."</td></tr>");
                f_echo("<tr><td>Provincia : "."</td><td>".$v_row["provincia"]."</td></tr>");
                f_echo("<tr><td>Código Postal : "."</td><td>".$v_row["cod_postal"]."</td></tr>");
                f_echo("</table>");
                f_echo("<hr>");
                f_echo("<a href='?accion=ver_clientes'>Ver Clientes</a><br>");
                
// Borrar los datos leidos de la tabla
$v_data->close();
// Desconectar MySQL server
$v_conn->close();
		
?>
