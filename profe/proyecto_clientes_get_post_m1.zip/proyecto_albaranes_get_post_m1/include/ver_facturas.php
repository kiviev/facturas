<?php

	// Script para gestionar FACTURAS
	
	f_echo("Código para gestionar Facturas");
        
        $v_conn = f_conn();
	
	$v_query = "SELECT id, fecha_emision, cliente_id FROM facturas";
	
	$v_data = $v_conn->query($v_query);
	
	
	f_echo("<table border=1>");
	f_echo("<tr><th>id</th><th>Fecha Emisión</th><th>Cod. Cliente</th></tr>");
        
	while ($v_row = $v_data->fetch_assoc()) {
		f_echo("<tr>");
		f_echo("<td><a href='?accion=det_factura&code=".$v_row["id"]."'>".$v_row["id"]."</a></td>");
		f_echo("<td>".$v_row["fecha_emision"]."</td>");
		f_echo("<td>".$v_row["cliente_id"]."</td>");
		f_echo("</tr>");
	}
	f_echo("</table>");
        
# Borrar los datos leidos de la tabla
$v_data->close();
# Desconectar MySQL server
$v_conn->close();

?>