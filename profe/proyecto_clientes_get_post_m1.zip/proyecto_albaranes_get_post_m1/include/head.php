<?php
	
	// Genera ETIQUETAS de inicio de página
	
	f_echo("<html>");
	f_echo("<head>");
	f_echo("<body>");
	
	f_echo("<table>");
	f_echo("<tr>");
	f_echo("<td width=200><a href='?'><small>Aplicación de Gestión</small></a></td>");
	f_echo("<td width=200><small>Sistema de autenticación desactivado</small></td>");
	f_echo("</td>");
	f_echo("</tr></table>");
	f_echo("<hr>");
	
?>
