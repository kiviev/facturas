<?php
	
	// Genera ETIQUETAS de fin de página
	
	
	echo "<hr>";
    
    f_echo("<small>2015. Curso de MySQL y PHP. Todos los derechos reservados</small>");
	
    echo "</body>\n";
	echo "</html>\n";
	
?>
