<?php

	// Script para gestionar PRODUCTOS
	
	f_echo("Código para gestionar Productos");
        
	$v_conn = f_conn();
	
	$v_query = "SELECT id, nombre, tipo, precio_compra, precio_venta
				FROM productos";
	
	$v_data = $v_conn->query($v_query);
	
	f_echo("<table border=1>");
	f_echo("<tr><th>id</th><th>Nombre</th><th>Tipo</th>
		   <th>Precio Compra</th><th>Precio Venta</th></tr>");
                   	
	while ($v_row = $v_data->fetch_assoc()) {
		f_echo("<tr>");
		f_echo("<td><a href='?accion=det_producto'>".$v_row["id"]."</a></td>");
		f_echo("<td>".$v_row["nombre"]."</td>");
		f_echo("<td>".$v_row["tipo"]."</td>");
		f_echo("<td>".$v_row["precio_compra"]."</td>");
		f_echo("<td>".$v_row["precio_venta"]."</td>");
                f_echo("</tr>");
	}
	f_echo("</table>");

# Borrar los datos leidos de la tabla
$v_data->close();
# Desconectar MySQL server
$v_conn->close();

?>
