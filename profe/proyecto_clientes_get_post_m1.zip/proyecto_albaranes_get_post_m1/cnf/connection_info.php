<?php

    // Constantes para conexión a base de datos
    define(DB_CONN_HOST, "localhost");
    define(DB_CONN_USER, "root");
    define(DB_CONN_PASS, "");
    define(DB_CONN_DEF_SCHEMA, "gestion");
    
    define(DB_SCHEMA_WORLD, "gestion");
    
    define(DB_TAB_GESTION_CLI, "clientes");
    define(DB_TAB_GESTION_ALB, "albaranes");
    define(DB_TAB_GESTION_FAC, "facturas");
    define(DB_TAB_GESTION_ALB_FAC, "albaranes_facturas");
    define(DB_TAB_GESTION_PRO, "productos");
    define(DB_TAB_GESTION_USU, "usuarios");
    define(DB_TAB_GESTION_PRI, "privilegios");
?>
