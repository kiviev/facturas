<?php

	// Comprobaciones iniciales
		
	
	
	
	// Funciones generales
	require("fnc/f_sistema.php");
	require("fnc/f_bbdd.php");
	
	// Envio de HEAD
	require("include/head.php");
	

	
	// Comprobar acciones
        if(!empty($_POST)) {  
            /*
            f_echo("<h1>Entrada por POST</h1>");
            foreach($_POST as $v_accion => $valor){
            } 
            f_echo("Acción : ".$v_accion."<br>");
            f_echo("Valor  : ".$valor."<br>");
			*/
			$v_frm_accion = $_POST["accion"];
			$v_accion = $v_frm_accion;
			
        } else {
            
            $v_accion = $_GET["accion"];  
           
        }

	switch ( $v_accion ) {

            case "ver_clientes":
                // Se solicita el script que gestiona CLIENTES
		require("include/ver_clientes.php");
                break;
            
            case "det_cliente":
                // Se solicita el script que gestiona DETALLE DE CLIENTES
		require("include/det_cliente.php");
                break;
            
            case "ver_albaranes":
                // Se solicita el script que gestiona ALBARANES
		require("include/ver_albaranes.php");
                break;
            
            case "det_albaran":
                // Se solicita el script que gestiona DETALLE DE ALBARANES
		require("include/det_albaran.php");
                break;
            
            case "ver_facturas":
		// Se solicita el script que gestiona FACTURAS
                require("include/ver_facturas.php");
                break;

            case "det_factura":
		// Se solicita el script que gestiona DETALLE DE FACTURAS
                require("include/det_factura.php");
                break;
            
            case "ver_productos":
		// Se solicita el script que gestiona PRODUCTOS
                require("include/ver_productos.php");
                break;
            
            default:
		// Se muestra el menú principal
	        require("html/menu_principal.html");                
            
        }
	
	
	
	
	
	
	
	
	
	// Envio de FOOT
	require("include/foot.php");


?>
